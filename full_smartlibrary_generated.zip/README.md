# SmartLibrary - Generated Full System (Demo Mode)

This package contains a working SmartLibrary demo scaffold (in-memory mode) and all assets.
Files of interest:
- backend/: models, DAO (demo), service
- gui/: PyQt5 GUI that displays generated screens (requires PyQt5)
- database/: schema.sql and seed_books.sql with 500 books and authors
- assets/images/: modern UI images for login, catalog, dashboard, ERD, UML
- run_local.py: quick demo runner (no DB required)
- requirements.txt: dependencies

Quick demo:
1. python -m venv venv
2. source venv/bin/activate  (Windows: venv\\Scripts\\activate)
3. pip install -r requirements.txt
4. python run_local.py

To use with PostgreSQL:
- Create DB and import database/schema.sql and database/seed_books.sql
- Set DATABASE_URL in .env and update backend/dao.py to use real DB connections (scaffold currently demo-only)

If you want interactive GUI screens (fully functional CRUD with DB), I can implement them next.
