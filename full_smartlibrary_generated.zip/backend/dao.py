# Simple DAO with in-memory demo mode (no DB required)
import os
from typing import Optional, List
from .models import Book, Author, User, Loan, Role
from datetime import datetime
from dotenv import load_dotenv
load_dotenv()

DATABASE_URL = os.getenv('DATABASE_URL')

class DAO:
    def __init__(self, dsn: Optional[str] = None):
        self.dsn = dsn or DATABASE_URL
        self.use_demo = not bool(self.dsn)
        if self.use_demo:
            self._books = {}
            self._users = {}
            self._loans = {}
            self._next = 1

    def _mkid(self):
        self._next += 1
        return self._next - 1

    # Demo methods
    def demo_seed(self, books, users=None):
        # books: list of (title,isbn,author)
        for b in books:
            bid = self._mkid()
            book = Book(id=bid, title=b[0], isbn=b[1], total_copies=1, copies_available=1, authors=[Author(name=b[2])])
            self._books[bid] = book
        if users:
            for u in users:
                uid = self._mkid()
                user = User(id=uid, username=u[0], role=Role(name=u[1]))
                self._users[uid] = user

    def list_books(self):
        if self.use_demo:
            return list(self._books.values())
        raise RuntimeError('DB mode not implemented in this demo')

    def create_user_if_not_exists(self, username, role='Member'):
        if self.use_demo:
            for u in self._users.values():
                if u.username == username:
                    return u
            uid = self._mkid()
            user = User(id=uid, username=username, role=Role(name=role))
            self._users[uid] = user
            return user
        raise RuntimeError('DB mode not implemented in this demo')

    def create_loan(self, book_id, member_id):
        if self.use_demo:
            book = self._books.get(book_id)
            if not book: raise RuntimeError('Book not found')
            active = [l for l in self._loans.values() if l.member_id==member_id and l.returned_at is None]
            if len(active) >= 3: raise RuntimeError('Member reached max active loans')
            book.borrow()
            lid = self._mkid()
            loan = Loan(id=lid, book_id=book_id, member_id=member_id)
            self._loans[lid] = loan
            return loan
        raise RuntimeError('DB mode not implemented in this demo')

    def return_loan(self, loan_id):
        if self.use_demo:
            loan = self._loans.get(loan_id)
            if not loan: raise RuntimeError('Loan not found')
            loan.returned_at = datetime.utcnow()
            book = self._books.get(loan.book_id)
            if book: book.return_copy()
            return loan
        raise RuntimeError('DB mode not implemented in this demo')
