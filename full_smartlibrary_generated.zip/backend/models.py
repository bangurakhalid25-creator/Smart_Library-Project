from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional

@dataclass
class Role:
    id: Optional[int] = None
    name: str = "Member"

@dataclass
class User:
    id: Optional[int] = None
    username: str = ""
    role: Role = field(default_factory=lambda: Role(name='Member'))

    def is_librarian(self)->bool:
        return self.role and self.role.name.lower() == 'librarian'

@dataclass
class Author:
    id: Optional[int] = None
    name: str = ""

@dataclass
class Book:
    id: Optional[int] = None
    title: str = ""
    authors: List[Author] = field(default_factory=list)
    isbn: Optional[str] = None
    total_copies: int = 1
    copies_available: int = 1

    def borrow(self):
        if self.copies_available <= 0:
            raise RuntimeError('No copies available')
        self.copies_available -= 1

    def return_copy(self):
        if self.copies_available >= self.total_copies:
            raise RuntimeError('All copies already in library')
        self.copies_available += 1

@dataclass
class Loan:
    id: Optional[int] = None
    book_id: int = 0
    member_id: int = 0
    borrowed_at: datetime = field(default_factory=datetime.utcnow)
    due_date: datetime = field(default_factory=lambda: datetime.utcnow() + timedelta(days=7))
    returned_at: Optional[datetime] = None

    def is_overdue(self)->bool:
        if self.returned_at:
            return self.returned_at > self.due_date
        return datetime.utcnow() > self.due_date
