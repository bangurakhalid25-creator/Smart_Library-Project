from .dao import DAO
from .models import Book, User, Loan
from typing import List

class LibraryService:
    def __init__(self, dao: DAO):
        self.dao = dao

    def list_books(self) -> List[Book]:
        return self.dao.list_books()

    def login_or_register(self, username: str, role: str='Member') -> User:
        return self.dao.create_user_if_not_exists(username, role)

    def borrow_book(self, book_id: int, member_id: int) -> Loan:
        return self.dao.create_loan(book_id, member_id)

    def return_loan(self, loan_id: int):
        return self.dao.return_loan(loan_id)
