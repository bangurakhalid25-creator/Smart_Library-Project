from backend.dao import DAO
from backend.service import LibraryService
import gui.main as gui_main

# seed a few demo items and run GUI
dao = DAO()
sample = [('1984','9780451524935','George Orwell'),('Brave New World','9780060850524','Aldous Huxley'),('The Great Gatsby','9780743273565','F. Scott Fitzgerald')]
dao.demo_seed(sample, users=[('alice','Member'),('librarian','Librarian')])
service = LibraryService(dao)
gui_main.main()
