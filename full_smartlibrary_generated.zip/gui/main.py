import sys, os
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QHBoxLayout, QListWidget, QStackedWidget)
from PyQt5.QtGui import QPixmap
from backend.dao import DAO
from backend.service import LibraryService

ASSET_PATH = os.path.join(os.path.dirname(__file__),'..','assets','images')

class ImageScreen(QWidget):
    def __init__(self, image_file):
        super().__init__()
        layout = QVBoxLayout()
        lbl = QLabel()
        pix = QPixmap(image_file)
        lbl.setPixmap(pix)
        lbl.setScaledContents(True)
        layout.addWidget(lbl)
        self.setLayout(layout)

class MainWindow(QWidget):
    def __init__(self, service):
        super().__init__()
        self.setWindowTitle('SmartLibrary - Demo UI')
        self.resize(1000,700)
        layout = QHBoxLayout()
        menu = QVBoxLayout()
        self.btn_login = QPushButton('Login Screen')
        self.btn_catalog = QPushButton('Catalog')
        self.btn_dashboard = QPushButton('Dashboard')
        self.btn_erd = QPushButton('ER Diagram')
        self.btn_uml = QPushButton('UML Diagram')
        menu.addWidget(self.btn_login); menu.addWidget(self.btn_catalog); menu.addWidget(self.btn_dashboard); menu.addWidget(self.btn_erd); menu.addWidget(self.btn_uml)
        self.stack = QStackedWidget()
        self.login_screen = ImageScreen(os.path.join(ASSET_PATH,'login.png'))
        self.catalog_screen = ImageScreen(os.path.join(ASSET_PATH,'catalog.png'))
        self.dashboard_screen = ImageScreen(os.path.join(ASSET_PATH,'dashboard.png'))
        self.erd_screen = ImageScreen(os.path.join(ASSET_PATH,'erd.png'))
        self.uml_screen = ImageScreen(os.path.join(ASSET_PATH,'uml.png'))
        for s in [self.login_screen,self.catalog_screen,self.dashboard_screen,self.erd_screen,self.uml_screen]:
            self.stack.addWidget(s)
        self.btn_login.clicked.connect(lambda: self.stack.setCurrentWidget(self.login_screen))
        self.btn_catalog.clicked.connect(lambda: self.stack.setCurrentWidget(self.catalog_screen))
        self.btn_dashboard.clicked.connect(lambda: self.stack.setCurrentWidget(self.dashboard_screen))
        self.btn_erd.clicked.connect(lambda: self.stack.setCurrentWidget(self.erd_screen))
        self.btn_uml.clicked.connect(lambda: self.stack.setCurrentWidget(self.uml_screen))
        layout.addLayout(menu,1)
        layout.addWidget(self.stack,4)
        self.setLayout(layout)

def main():
    app = QApplication(sys.argv)
    dao = DAO()
    service = LibraryService(dao)
    w = MainWindow(service)
    w.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
